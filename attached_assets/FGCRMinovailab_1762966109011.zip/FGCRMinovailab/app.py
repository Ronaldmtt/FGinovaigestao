import os
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect
from functools import wraps
from models import db, Contato, Comentario, Usuario
from datetime import datetime
from sqlalchemy.exc import IntegrityError

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['GESTAO_URL'] = os.environ.get('GESTAO_URL', 'https://0503954a-d45b-4e9d-8905-65eb0d7e68e8-00-4zptzh9tjj9a.kirk.replit.dev/dashboard')

app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 3600,
    'pool_size': 10,
    'max_overflow': 20,
    'connect_args': {
        'connect_timeout': 10,
        'keepalives': 1,
        'keepalives_idle': 30,
        'keepalives_interval': 10,
        'keepalives_count': 5
    }
}

db.init_app(app)
csrf = CSRFProtect(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Por favor, faça login para acessar esta página.'
login_manager.login_message_category = 'warning'

ESTAGIOS = [
    'Captação',
    'Qualificação Automática',
    'Contato Inicial',
    'Diagnóstico / Levantamento de Dor',
    'Apresentação de POC',
    'Proposta Técnica e Comercial',
    'Negociação e Follow-up',
    'Fechamento e Onboarding',
    'Pós-venda e Expansão'
]

@login_manager.user_loader
def load_user(user_id):
    return Usuario.query.get(int(user_id))

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Acesso negado. Você precisa ser administrador.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def init_db():
    """Inicializa o banco de dados e cria o usuário administrador padrão se necessário.
    
    Esta função é idempotente e segura para execução em múltiplos workers.
    """
    # Verificar se DATABASE_URL está configurada
    if not os.environ.get('DATABASE_URL'):
        print('[InnovaPipe] DATABASE_URL não configurada. Pulando inicialização do banco.')
        return
    
    with app.app_context():
        try:
            # Criar todas as tabelas
            db.create_all()
            print('[InnovaPipe] Tabelas do banco de dados verificadas/criadas.')
            
            # Verificar se existe algum usuário administrador
            admin_exists = Usuario.query.filter_by(is_admin=True).first()
            
            if not admin_exists:
                print('[InnovaPipe] Nenhum administrador encontrado. Criando usuário admin padrão...')
                try:
                    admin = Usuario(
                        nome='Administrador inovai.lab',
                        email='admin@inovailab.com',
                        is_admin=True,
                        ativo=True
                    )
                    admin.set_password('inovai2025')
                    db.session.add(admin)
                    db.session.commit()
                    print('[InnovaPipe] ✓ Usuário admin criado com sucesso!')
                    print('[InnovaPipe]   Email: admin@inovailab.com')
                    print('[InnovaPipe]   Senha: inovai2025')
                    print('[InnovaPipe]   IMPORTANTE: Altere a senha após o primeiro login!')
                except IntegrityError:
                    # Outro worker/processo já criou o admin (race condition)
                    db.session.rollback()
                    print('[InnovaPipe] Administrador já foi criado por outro processo.')
            else:
                print(f'[InnovaPipe] Administrador já existe: {admin_exists.email}')
                
        except Exception as e:
            print(f'[InnovaPipe] ERRO ao inicializar banco de dados: {str(e)}')
            # Não levantar a exceção para não quebrar a importação
            import traceback
            traceback.print_exc()

# Inicializar o banco de dados apenas se estamos executando diretamente
# ou através de um servidor WSGI
if os.environ.get('DATABASE_URL'):
    try:
        init_db()
    except Exception:
        # Já logado dentro de init_db()
        pass


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        lembrar = request.form.get('lembrar', False)
        
        usuario = Usuario.query.filter_by(email=email).first()
        
        if usuario and usuario.check_password(senha):
            if not usuario.ativo:
                flash('Sua conta está inativa. Entre em contato com o administrador.', 'danger')
                return redirect(url_for('login'))
            
            login_user(usuario, remember=lembrar)
            flash(f'Bem-vindo, {usuario.nome}!', 'success')
            
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('Email ou senha incorretos.', 'danger')
    
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('login'))


@app.route('/')
@login_required
def index():
    contatos_por_estagio = {}
    for estagio in ESTAGIOS:
        contatos_por_estagio[estagio] = Contato.query.filter_by(estagio=estagio).all()
    
    total_contatos = Contato.query.count()
    
    return render_template('index.html', 
                         contatos_por_estagio=contatos_por_estagio,
                         estagios=ESTAGIOS,
                         total_contatos=total_contatos)


@app.route('/contato/novo', methods=['GET', 'POST'])
@login_required
def novo_contato():
    if request.method == 'POST':
        contato = Contato(
            nome_empresa=request.form['nome_empresa'],
            nome_contato=request.form['nome_contato'],
            email=request.form['email'],
            telefone=request.form['telefone'],
            observacoes=request.form.get('observacoes', ''),
            estagio=request.form.get('estagio', 'Captação')
        )
        db.session.add(contato)
        db.session.commit()
        flash('Contato cadastrado com sucesso!', 'success')
        return redirect(url_for('index'))
    
    return render_template('novo_contato.html', estagios=ESTAGIOS)


@app.route('/contato/<int:id>')
@login_required
def ver_contato(id):
    contato = Contato.query.get_or_404(id)
    return render_template('ver_contato.html', contato=contato, estagios=ESTAGIOS)


@app.route('/contato/<int:id>/editar', methods=['GET', 'POST'])
@login_required
def editar_contato(id):
    contato = Contato.query.get_or_404(id)
    
    if request.method == 'POST':
        contato.nome_empresa = request.form['nome_empresa']
        contato.nome_contato = request.form['nome_contato']
        contato.email = request.form['email']
        contato.telefone = request.form['telefone']
        contato.observacoes = request.form.get('observacoes', '')
        contato.estagio = request.form['estagio']
        contato.data_atualizacao = datetime.utcnow()
        
        db.session.commit()
        flash('Contato atualizado com sucesso!', 'success')
        return redirect(url_for('ver_contato', id=id))
    
    return render_template('editar_contato.html', contato=contato, estagios=ESTAGIOS)


@app.route('/contato/<int:id>/deletar', methods=['POST'])
@login_required
def deletar_contato(id):
    contato = Contato.query.get_or_404(id)
    db.session.delete(contato)
    db.session.commit()
    flash('Contato deletado com sucesso!', 'success')
    return redirect(url_for('index'))


@app.route('/contato/<int:id>/mudar-estagio', methods=['POST'])
@login_required
def mudar_estagio(id):
    contato = Contato.query.get_or_404(id)
    novo_estagio = request.json.get('estagio')
    
    if novo_estagio in ESTAGIOS:
        contato.estagio = novo_estagio
        contato.data_atualizacao = datetime.utcnow()
        db.session.commit()
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Estágio inválido'}), 400


@app.route('/contato/<int:id>/comentario', methods=['POST'])
@login_required
def adicionar_comentario(id):
    contato = Contato.query.get_or_404(id)
    texto = request.form.get('texto')
    
    if texto:
        comentario = Comentario(contato_id=id, texto=texto)
        db.session.add(comentario)
        db.session.commit()
        flash('Comentário adicionado com sucesso!', 'success')
    
    return redirect(url_for('ver_contato', id=id))


@app.route('/buscar')
@login_required
def buscar():
    query = request.args.get('q', '')
    
    if query:
        contatos = Contato.query.filter(
            db.or_(
                Contato.nome_empresa.ilike(f'%{query}%'),
                Contato.nome_contato.ilike(f'%{query}%'),
                Contato.email.ilike(f'%{query}%'),
                Contato.telefone.ilike(f'%{query}%')
            )
        ).all()
    else:
        contatos = []
    
    return render_template('buscar.html', contatos=contatos, query=query)


@app.route('/admin/usuarios')
@login_required
@admin_required
def admin_usuarios():
    usuarios = Usuario.query.all()
    return render_template('admin_usuarios.html', usuarios=usuarios)


@app.route('/admin/usuario/novo', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_novo_usuario():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('senha')
        is_admin = request.form.get('is_admin') == 'on'
        
        if Usuario.query.filter_by(email=email).first():
            flash('Este email já está cadastrado.', 'danger')
            return redirect(url_for('admin_novo_usuario'))
        
        novo_usuario = Usuario(
            nome=nome,
            email=email,
            is_admin=is_admin,
            ativo=True
        )
        novo_usuario.set_password(senha)
        
        db.session.add(novo_usuario)
        db.session.commit()
        
        flash('Usuário criado com sucesso!', 'success')
        return redirect(url_for('admin_usuarios'))
    
    return render_template('admin_novo_usuario.html')


@app.route('/admin/usuario/<int:id>/editar', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_editar_usuario(id):
    usuario = Usuario.query.get_or_404(id)
    
    if request.method == 'POST':
        usuario.nome = request.form.get('nome')
        usuario.email = request.form.get('email')
        usuario.is_admin = request.form.get('is_admin') == 'on'
        usuario.ativo = request.form.get('ativo') == 'on'
        
        nova_senha = request.form.get('nova_senha')
        if nova_senha:
            usuario.set_password(nova_senha)
        
        db.session.commit()
        flash('Usuário atualizado com sucesso!', 'success')
        return redirect(url_for('admin_usuarios'))
    
    return render_template('admin_editar_usuario.html', usuario=usuario)


@app.route('/admin/usuario/<int:id>/deletar', methods=['POST'])
@login_required
@admin_required
def admin_deletar_usuario(id):
    if id == current_user.id:
        flash('Você não pode deletar sua própria conta.', 'danger')
        return redirect(url_for('admin_usuarios'))
    
    usuario = Usuario.query.get_or_404(id)
    db.session.delete(usuario)
    db.session.commit()
    flash('Usuário deletado com sucesso!', 'success')
    return redirect(url_for('admin_usuarios'))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
