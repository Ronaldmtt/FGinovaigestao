# InnovaPipe - inovai.lab

## Visão Geral
InnovaPipe é um sistema CRM (Customer Relationship Management) desenvolvido em Flask exclusivamente para a **inovai.lab**, focado em gerenciar contatos e pipeline de vendas com 9 estágios personalizados.

## Funcionalidades
### Gerenciamento de Contatos
- Cadastro completo de contatos com empresa, nome, email, telefone e observações
- Pipeline visual com 9 estágios de vendas
- Sistema de comentários para histórico de interações
- Busca de contatos
- Movimentação de contatos entre estágios
- Dashboard com visão geral do funil

### Autenticação e Segurança
- Sistema de login e senha
- Controle de sessões com Flask-Login
- Senhas criptografadas com hash seguro
- Todas as páginas protegidas por autenticação
- Apenas administradores podem criar novos usuários (sem registro público)

### Administração de Usuários (Exclusivo para Administradores)
- Painel administrativo para gerenciar usuários
- Criação, edição e exclusão de usuários
- Controle de permissões (usuário comum vs administrador)
- Ativação/desativação de contas
- **Importante:** Não há registro público - apenas administradores podem criar novos usuários

## Estrutura do Projeto
```
├── app.py                 # Aplicação principal Flask com autenticação
├── models.py              # Modelos de banco de dados (Usuario, Contato, Comentario)
├── templates/             # Templates HTML
│   ├── base.html                    # Template base com menu
│   ├── login.html                   # Página de login
│   ├── registro.html                # Registro de novos usuários
│   ├── index.html                   # Dashboard com pipeline
│   ├── novo_contato.html            # Formulário de cadastro
│   ├── ver_contato.html             # Detalhes e comentários
│   ├── editar_contato.html          # Edição de contato
│   ├── buscar.html                  # Busca de contatos
│   ├── admin_usuarios.html          # Lista de usuários (admin)
│   ├── admin_novo_usuario.html      # Criar usuário (admin)
│   └── admin_editar_usuario.html    # Editar usuário (admin)
└── static/               # Arquivos estáticos (CSS/JS)
    ├── style.css
    └── script.js
```

## Tecnologias
- Python 3.11
- Flask 3.1
- Flask-Login (gerenciamento de sessões)
- Flask-SQLAlchemy (ORM)
- PostgreSQL (banco de dados)
- Werkzeug (hash de senhas)
- Bootstrap 5 (interface)
- Bootstrap Icons

## Estágios do Pipeline
1. Captação (Lead Capturado)
2. Qualificação Automática (Lead Inteligente)
3. Contato Inicial (SQL – Sales Qualified Lead)
4. Diagnóstico / Levantamento de Dor
5. Apresentação de POC
6. Proposta Técnica e Comercial
7. Negociação e Follow-up
8. Fechamento e Onboarding
9. Pós-venda e Expansão

## Banco de Dados
- PostgreSQL gerenciado pelo Replit
- Três tabelas principais: `usuarios`, `contatos` e `comentarios`
- Relacionamento one-to-many entre contatos e comentários
- Senhas armazenadas com hash seguro (werkzeug.security)

## Credenciais Padrão
Na primeira execução, um usuário administrador é criado automaticamente:
- **Email:** admin@inovailab.com
- **Senha:** inovai2025

⚠️ **Importante:** Altere a senha do administrador após o primeiro login!

## Como Usar
1. Acesse o sistema - será redirecionado para a tela de login
2. Faça login com as credenciais do administrador
3. Administradores podem criar novos usuários através do menu "Usuários" > "Novo Usuário"
4. Cadastre contatos e gerencie seu pipeline de vendas
5. Adicione comentários para registrar interações com cada contato
6. Use o botão "Voltar para Gestão" no menu para retornar ao sistema de gestão inovai.lab

**Nota:** Não há registro público. Apenas administradores podem criar novas contas de usuários.

## Integração com Sistema de Gestão
O InnovaPipe está integrado com o sistema de gestão inovai.lab:
- **Botão "Voltar para Gestão"** no menu superior redireciona para o dashboard do sistema de gestão
- URL de desenvolvimento: https://0503954a-d45b-4e9d-8905-65eb0d7e68e8-00-4zptzh9tjj9a.kirk.replit.dev/dashboard
- URL configurável via variável de ambiente `GESTAO_URL`
- Navegação fluida entre os dois sistemas

## Inicialização Automática em Produção
O InnovaPipe possui um sistema de inicialização automática que garante a criação do usuário administrador:

- **Primeira execução**: Quando a aplicação é iniciada pela primeira vez (desenvolvimento ou produção), o sistema automaticamente:
  1. Cria todas as tabelas necessárias no banco de dados
  2. Verifica se existe um usuário administrador
  3. Se não existir, cria o usuário padrão: admin@inovailab.com / inovai2025
  4. Loga todas as operações para facilitar debug

- **Proteções implementadas**:
  - Idempotência: pode ser executado múltiplas vezes sem criar duplicatas
  - Race condition protection: se múltiplos workers tentarem criar simultaneamente, apenas um terá sucesso
  - Graceful failure: se o banco não estiver disponível, não impede a inicialização do app
  - Logs detalhados: todas as operações são logadas com prefixo [InnovaPipe]

- **Verificação dos logs**: Após publicar/reiniciar, verifique os logs para confirmar:
  ```
  [InnovaPipe] Tabelas do banco de dados verificadas/criadas.
  [InnovaPipe] ✓ Usuário admin criado com sucesso!
  ```
  ou
  ```
  [InnovaPipe] Administrador já existe: admin@inovailab.com
  ```

## Deployment (Publicação)
O InnovaPipe está configurado para deployment automático no Replit:
- **Tipo:** Autoscale (escala automática conforme demanda)
- **Servidor:** Gunicorn (servidor de produção otimizado para Flask)
- **Build:** Instalação automática de dependências via `requirements.txt`
- **Run:** `gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`

Para publicar:
1. Clique no botão "Deploy" no Replit
2. O sistema instalará automaticamente todas as dependências
3. O Gunicorn iniciará o servidor em modo produção
4. Sua aplicação estará disponível com URL pública e SSL

## Data de Criação
26 de outubro de 2025

## Última Atualização
26 de outubro de 2025 - Sistema personalizado para inovai.lab com branding "InnovaPipe"

---

**Desenvolvido com ❤️ para inovai.lab**
